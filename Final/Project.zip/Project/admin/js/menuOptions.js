function openPosts()
{	
	window.location = "Posts.html";
}

function openNotification()
{
	window.location = "AdminNotifications.html";
}

function openSchedule()
{
	window.location = "AdminCalender.html";
}

function openCalender()
{
	window.location = "AdminCalender.html";
}

/*function openPeople()
{
	window.location = "People.html";
}

function openGeneral()
{
	window.location = "General.html";
}

function openHistory()
{
	window.location = "History.html";
}*/

function openSettings()
{
	window.location = "AdminSettings.html";
}

function openMessages()
{
	window.location = "AdminMessages.html"
}

function openCourses()
{
	window.location = "AdminCourses.html";
}

function openHome()
{
	window.location = "AdminHome.html";
}

function openLogin()
{
	window.location = "../index.html";
}
