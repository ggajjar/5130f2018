function openPosts()
{	
	window.location = "Posts.html";
}

function openNotification()
{
	window.location = "Notification.html";
}

function openGrades()
{
	window.location = "Grades.html";
}

function openCalender()
{
	window.location = "Calender.html";
}

function openPeople()
{
	window.location = "People.html";
}

function openGeneral()
{
	window.location = "General.html";
}

function openHistory()
{
	window.location = "History.html";
}

function openSettings()
{
	window.location = "Settings.html";
}

function openMessages()
{
	window.location = "Messages.html"
}

function openCourses()
{
	window.location = "Courses.html";
}

function openHome()
{
	window.location = "Home.html";
}

function openLogin()
{
	window.location = "index.html";
}
